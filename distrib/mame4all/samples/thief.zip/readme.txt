Theif samples updated by Dith 17th Jan 2001

The speech from Theif needed some serious noise reduction. This has made a massive improvement, it's now much cleaner and the file size is a bit smaller.

I've resampled it to 11Khz as the sound was very dull and used no frequencies above this. 

www.mameworld.net/dith
