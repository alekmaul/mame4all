Nato Defence samples updated by Dith 17th Jan 2001

The speech from Nato Defence needed some serious noise reduction. This has made a massive improvement, it's now much cleaner and the file size is a lot smaller.

The speech has been noise reduced and filtered with a new radio effect. I've also added a noise gate to remove 8 bit hiss. I've kept the samples at 16Khz as the sound lost it's edge when reduced to 11Khz. 

I have a 16-bit version of the noise reduced Nato Defence and Thief samples. The extra sound quality of the 16-bit version is hardly noticeable and does not justify the much larger file size.

www.mameworld.net/dith
